# Mobicom Design Studios Website - Google Cloud Hosting

## Option A: Google App Engine static hosting
1. Install and login to Google Cloud CLI.
2. Create/select your project:
   gcloud config set project YOUR_PROJECT_ID
3. Deploy from this folder:
   gcloud app deploy
4. Open:
   gcloud app browse

## Files
- index.html
- style.css
- script.js
- assets/mobicom-logo.png
- app.yaml

## Notes
The site uses local files only, so it will work without external image links.
